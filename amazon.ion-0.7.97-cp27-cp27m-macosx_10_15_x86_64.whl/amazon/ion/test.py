import os
import resource
import shutil
import time
from os.path import abspath, join, dirname, isdir

from amazon.ion import simpleion

if __name__ == "__main__":
    obj = "afsfsdf"
    print(simpleion.dumps(simpleion.loads(obj), binary=False))

    # with open('service_log3', 'rb') as fp:
    #     init_m = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    #     start_time = time.time()
    #     obj = simpleion.load(fp, single_value=False, force_python_impl=False)
    #     # print(obj)
    #     print("--- %s seconds ---" % (time.time() - start_time))
    #     final_m = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    #     print("memory gap: %s - %s = %s" % (final_m, init_m, final_m - init_m))
